import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../db/database_helper.dart';
import '../models/product.dart';
import '../models/sale.dart';
import 'product_form_screen.dart';
import 'history_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _currency = NumberFormat.currency(locale: 'es_CL', symbol: '\$', decimalDigits: 0);
  List<Product> _products = [];
  final Map<int, CartItem> _cart = {}; // productId -> CartItem
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadProducts();
  }

  Future<void> _loadProducts() async {
    setState(() => _loading = true);
    final products = await DatabaseHelper.instance.getAllProducts();
    setState(() {
      _products = products;
      _loading = false;
    });
  }

  void _addToCart(Product p) {
    if (p.stock <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${p.name} no tiene stock disponible')),
      );
      return;
    }
    setState(() {
      final existing = _cart[p.id];
      if (existing != null) {
        if (existing.quantity < p.stock) {
          existing.quantity++;
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('No hay más stock de ${p.name}')),
          );
        }
      } else {
        _cart[p.id!] = CartItem(
          productId: p.id!,
          productName: p.name,
          unitPrice: p.price,
          availableStock: p.stock,
          quantity: 1,
        );
      }
    });
  }

  void _decreaseFromCart(int productId) {
    setState(() {
      final item = _cart[productId];
      if (item == null) return;
      if (item.quantity > 1) {
        item.quantity--;
      } else {
        _cart.remove(productId);
      }
    });
  }

  int get _cartTotal =>
      _cart.values.fold(0, (sum, it) => sum + it.subtotal);

  Future<void> _checkout() async {
    if (_cart.isEmpty) return;
    final total = _cartTotal;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Confirmar cobro en efectivo'),
        content: Text('Total a cobrar: ${_currency.format(total)}'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Confirmar'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    await DatabaseHelper.instance.registerSale(_cart.values.toList());
    setState(() => _cart.clear());
    await _loadProducts();

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Venta registrada: ${_currency.format(total)}')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('POS Retail'),
        actions: [
          IconButton(
            icon: const Icon(Icons.history),
            tooltip: 'Historial de ventas',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const HistoryScreen()),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.add_box),
            tooltip: 'Nuevo producto',
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const ProductFormScreen()),
              );
              _loadProducts();
            },
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _products.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                      'No tienes productos aún.\nToca el ícono + arriba para agregar el primero.',
                      textAlign: TextAlign.center,
                    ),
                  ),
                )
              : Column(
                  children: [
                    Expanded(
                      child: ListView.builder(
                        itemCount: _products.length,
                        itemBuilder: (context, i) {
                          final p = _products[i];
                          final inCart = _cart[p.id]?.quantity ?? 0;
                          return ListTile(
                            title: Text(p.name),
                            subtitle: Text(
                              '${_currency.format(p.price)}  ·  Stock: ${p.stock}',
                            ),
                            onTap: () => _addToCart(p),
                            onLongPress: () async {
                              await Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => ProductFormScreen(product: p),
                                ),
                              );
                              _loadProducts();
                            },
                            trailing: inCart > 0
                                ? Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      IconButton(
                                        icon: const Icon(Icons.remove_circle_outline),
                                        onPressed: () => _decreaseFromCart(p.id!),
                                      ),
                                      Text('$inCart',
                                          style: const TextStyle(fontWeight: FontWeight.bold)),
                                      IconButton(
                                        icon: const Icon(Icons.add_circle_outline),
                                        onPressed: () => _addToCart(p),
                                      ),
                                    ],
                                  )
                                : null,
                          );
                        },
                      ),
                    ),
                    if (_cart.isNotEmpty)
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.surfaceContainerHigh,
                          boxShadow: const [BoxShadow(blurRadius: 4, color: Colors.black26)],
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(
                                'Total: ${_currency.format(_cartTotal)}',
                                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                              ),
                            ),
                            FilledButton.icon(
                              onPressed: _checkout,
                              icon: const Icon(Icons.payments),
                              label: const Text('Cobrar efectivo'),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
    );
  }
}
