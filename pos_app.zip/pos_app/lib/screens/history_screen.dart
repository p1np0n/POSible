import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../db/database_helper.dart';
import '../models/sale.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final _currency = NumberFormat.currency(locale: 'es_CL', symbol: '\$', decimalDigits: 0);
  final _time = DateFormat('HH:mm');
  DateTime _selectedDay = DateTime.now();
  List<Sale> _sales = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final sales = await DatabaseHelper.instance.getSalesForDay(_selectedDay);
    setState(() {
      _sales = sales;
      _loading = false;
    });
  }

  Future<void> _pickDay() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDay,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() => _selectedDay = picked);
      _load();
    }
  }

  int get _dayTotal => _sales.fold(0, (sum, s) => sum + s.total);

  @override
  Widget build(BuildContext context) {
    final dateLabel = DateFormat('dd/MM/yyyy').format(_selectedDay);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Historial de ventas'),
        actions: [
          IconButton(icon: const Icon(Icons.calendar_today), onPressed: _pickDay),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(dateLabel, style: const TextStyle(fontSize: 16)),
                      Text(
                        'Total día: ${_currency.format(_dayTotal)}',
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: _sales.isEmpty
                      ? const Center(child: Text('Sin ventas registradas este día'))
                      : ListView.builder(
                          itemCount: _sales.length,
                          itemBuilder: (context, i) {
                            final s = _sales[i];
                            final dt = DateTime.parse(s.dateTime);
                            return ExpansionTile(
                              title: Text(_currency.format(s.total)),
                              subtitle: Text(_time.format(dt)),
                              children: [
                                FutureBuilder<List<SaleItem>>(
                                  future: DatabaseHelper.instance.getItemsForSale(s.id!),
                                  builder: (context, snap) {
                                    if (!snap.hasData) {
                                      return const Padding(
                                        padding: EdgeInsets.all(8),
                                        child: CircularProgressIndicator(),
                                      );
                                    }
                                    final items = snap.data!;
                                    return Column(
                                      children: items
                                          .map((it) => ListTile(
                                                dense: true,
                                                title: Text(it.productName),
                                                trailing: Text(
                                                    '${it.quantity} x ${_currency.format(it.unitPrice)}'),
                                              ))
                                          .toList(),
                                    );
                                  },
                                ),
                              ],
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}
