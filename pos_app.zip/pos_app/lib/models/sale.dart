class Sale {
  final int? id;
  final String dateTime; // ISO8601
  final int total;

  Sale({this.id, required this.dateTime, required this.total});

  Map<String, dynamic> toMap() {
    return {'id': id, 'date_time': dateTime, 'total': total};
  }

  factory Sale.fromMap(Map<String, dynamic> map) {
    return Sale(
      id: map['id'] as int?,
      dateTime: map['date_time'] as String,
      total: map['total'] as int,
    );
  }
}

class SaleItem {
  final int? id;
  final int saleId;
  final int productId;
  final String productName;
  final int unitPrice;
  final int quantity;

  SaleItem({
    this.id,
    required this.saleId,
    required this.productId,
    required this.productName,
    required this.unitPrice,
    required this.quantity,
  });

  int get subtotal => unitPrice * quantity;

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'sale_id': saleId,
      'product_id': productId,
      'product_name': productName,
      'unit_price': unitPrice,
      'quantity': quantity,
    };
  }

  factory SaleItem.fromMap(Map<String, dynamic> map) {
    return SaleItem(
      id: map['id'] as int?,
      saleId: map['sale_id'] as int,
      productId: map['product_id'] as int,
      productName: map['product_name'] as String,
      unitPrice: map['unit_price'] as int,
      quantity: map['quantity'] as int,
    );
  }
}

/// Item temporal mientras se arma el carrito (antes de guardar la venta)
class CartItem {
  final int productId;
  final String productName;
  final int unitPrice;
  final int availableStock;
  int quantity;

  CartItem({
    required this.productId,
    required this.productName,
    required this.unitPrice,
    required this.availableStock,
    this.quantity = 1,
  });

  int get subtotal => unitPrice * quantity;
}
