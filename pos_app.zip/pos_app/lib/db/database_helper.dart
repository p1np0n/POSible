import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/product.dart';
import '../models/sale.dart';

class DatabaseHelper {
  DatabaseHelper._privateConstructor();
  static final DatabaseHelper instance = DatabaseHelper._privateConstructor();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'pos_retail.db');
    return await openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        price INTEGER NOT NULL,
        stock INTEGER NOT NULL
      )
    ''');
    await db.execute('''
      CREATE TABLE sales (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date_time TEXT NOT NULL,
        total INTEGER NOT NULL
      )
    ''');
    await db.execute('''
      CREATE TABLE sale_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sale_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        product_name TEXT NOT NULL,
        unit_price INTEGER NOT NULL,
        quantity INTEGER NOT NULL,
        FOREIGN KEY (sale_id) REFERENCES sales (id)
      )
    ''');
  }

  // ---------- PRODUCTOS ----------

  Future<int> insertProduct(Product p) async {
    final db = await database;
    return await db.insert('products', p.toMap()..remove('id'));
  }

  Future<int> updateProduct(Product p) async {
    final db = await database;
    return await db.update('products', p.toMap(),
        where: 'id = ?', whereArgs: [p.id]);
  }

  Future<int> deleteProduct(int id) async {
    final db = await database;
    return await db.delete('products', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Product>> getAllProducts() async {
    final db = await database;
    final maps = await db.query('products', orderBy: 'name ASC');
    return maps.map((m) => Product.fromMap(m)).toList();
  }

  Future<void> adjustStock(int productId, int delta) async {
    final db = await database;
    await db.rawUpdate(
      'UPDATE products SET stock = stock + ? WHERE id = ?',
      [delta, productId],
    );
  }

  // ---------- VENTAS ----------

  /// Guarda una venta completa (cabecera + items) y descuenta stock.
  /// Devuelve el id de la venta creada.
  Future<int> registerSale(List<CartItem> items) async {
    final db = await database;
    final total = items.fold<int>(0, (sum, it) => sum + it.subtotal);
    final now = DateTime.now().toIso8601String();

    return await db.transaction((txn) async {
      final saleId = await txn.insert('sales', {
        'date_time': now,
        'total': total,
      });

      for (final it in items) {
        await txn.insert('sale_items', {
          'sale_id': saleId,
          'product_id': it.productId,
          'product_name': it.productName,
          'unit_price': it.unitPrice,
          'quantity': it.quantity,
        });
        await txn.rawUpdate(
          'UPDATE products SET stock = stock - ? WHERE id = ?',
          [it.quantity, it.productId],
        );
      }
      return saleId;
    });
  }

  Future<List<Sale>> getSalesForDay(DateTime day) async {
    final db = await database;
    final start = DateTime(day.year, day.month, day.day).toIso8601String();
    final end = DateTime(day.year, day.month, day.day, 23, 59, 59)
        .toIso8601String();
    final maps = await db.query(
      'sales',
      where: 'date_time BETWEEN ? AND ?',
      whereArgs: [start, end],
      orderBy: 'date_time DESC',
    );
    return maps.map((m) => Sale.fromMap(m)).toList();
  }

  Future<List<SaleItem>> getItemsForSale(int saleId) async {
    final db = await database;
    final maps = await db.query('sale_items',
        where: 'sale_id = ?', whereArgs: [saleId]);
    return maps.map((m) => SaleItem.fromMap(m)).toList();
  }
}
